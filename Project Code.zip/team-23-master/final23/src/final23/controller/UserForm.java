package controller;

public class UserForm {
	
	private String content;
	
	private String result;
	
	public String getContent() {
	    return content;
	  }

	  public void setContent(String content) {
	    this.content = content;
	  }
	  
	public void setResult(String result) {
		this.result = result;
	}
	
	public String getResult() {
		return result;
	}


}
